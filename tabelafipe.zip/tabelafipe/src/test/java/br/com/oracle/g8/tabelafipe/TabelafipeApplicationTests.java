package br.com.oracle.g8.tabelafipe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TabelafipeApplicationTests {

	@Test
	void contextLoads() {
	}

}
